//
//  MKPlayer.h
//  MKPlayer
//
//  Created by Karthik K on 13/01/21.
//

#import <Foundation/Foundation.h>

//! Project version number for MKPlayer.
FOUNDATION_EXPORT double MKPlayerVersionNumber;

//! Project version string for MKPlayer.
FOUNDATION_EXPORT const unsigned char MKPlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MKPlayer/PublicHeader.h>


